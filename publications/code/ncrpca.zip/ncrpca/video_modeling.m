% This matlab script is used for comparing NcRPCA and convex RPCA (using
% IALM) on the foreground-background separation task. The datasets can be
% obtained at http://perception.i2r.a-star.edu.sg/bk_model/bk_index.html

close all;
clear;
clc;
j = 1;
for i = 700:963 % read image frames
    %img1 = im2double(rgb2gray(imread(['../ShoppingMall/ShoppingMall' num2str(i) '.bmp'])));
    img1 = im2double(rgb2gray(imread(['../curtain_sub/Curtain23' num2str(i) '.bmp'])));
    M(:, j) = reshape(img1, numel(img1), 1);
    j = j+1
end
[m n] = size(M);

EPS = 1e-3;
EPS_S = 1e-3;
MAX_ITER = 52;
r_hat = 10;

disp('starting low-rank+sparse matrix decomposition');
incoh = 1;
lambda = incoh/sqrt(m);
tic;
[M_t, L_t, S_t, iter_ncrpca, frob_err_ncrpca] = ncrpca(M, r_hat, EPS, MAX_ITER, EPS_S, incoh);
time_ncrpca = toc
tic;
[A_hat, E_hat, iter_alm, frob_err_alm] = inexact_alm_rpca(M, lambda, EPS, MAX_ITER);
time_alm = toc

% display the low rank components from the first frame with both methods
figure; imshow(reshape(L_t(:,1), size(img1, 1), size(img1, 2)));
figure; imshow(reshape(A_hat(:,1), size(img1, 1), size(img1, 2)));

%save(['Tvid_' 'm' num2str(m) 'n' num2str(n) 'r_hat' num2str(r_hat) '.mat']);
